source setup.sql

source ddl.sql

source insert.sql