DROP DATABASE IF EXISTS burger_orderer;
CREATE DATABASE burger_orderer;

USE burger_orderer;